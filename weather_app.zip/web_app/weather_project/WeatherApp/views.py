from django.shortcuts import render

# Create your views here.
import urllib.request
import json
import urllib.parse


def index(request):
    if request.method == 'POST':
        city = urllib.parse.quote(request.POST['city'])
        url = 'data/2.5/weather?q='+city+'&units=metric&appid=16496aef24a6c5290bf6ea0f0371bdce'
        url = 'http://api.openweathermap.org/' + url
        source = urllib.request.urlopen(url).read()
        list_of_data = json.loads(source)

        data = {
            "country_code": str(list_of_data['sys']['country']),
            "coordinate": str(list_of_data['coord']['lon']) + ', '
            + str(list_of_data['coord']['lat']),
            "temp": str(list_of_data['main']['temp']) + ' °C',
            "pressure": str(list_of_data['main']['pressure']),
            "humditiy": str(list_of_data['main']['humidity']),
            "main": str(list_of_data['weather'][0]['main']),
            "description": str(list_of_data['weather'][0]['description']),
            "icon": str(list_of_data['weather'][0]['icon'])
        } 
        print(data)
    else:
        data = {}

    return render(request, "main/index.html", data)                                       
